.data
	var1: .byte 'A', 'E', 127, -1, '\n'
	var2: .half -10, 0xffff
	var3: .word 0x12345678
	var4: .word 0:10
	var5: .float 12.3, 0.1
	var6: .double 0.1
	str1: .ascii "A String\n"
	str2: .asciiz "My fav sentence"
	array: .space 100
	name: .ascii "Anjney Lawaniya"
